DBFit dotnet binaries and dependencies version 1.1 (20080822) 

see http://gojko.net/fitnesse/dbfit.

package includes software from FitNesse and FitNesse.Net projects, released under GNU GPL

See http://www.fitnesse.org and http://www.sourceforge.net/projects/fitnessedotnet
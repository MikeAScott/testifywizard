namespace ThoughtWorks.TreeSurgeon.Core
{
	public interface IDirectoryBuilder
	{
		void CreateDirectory(string projectName);
	}
}
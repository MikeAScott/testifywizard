using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly : AssemblyTitle("Tree Surgeon Core")]
[assembly : AssemblyDescription("")]
[assembly : AssemblyConfiguration("")]

#if DEBUG
	[assembly: InternalsVisibleTo("ThoughtWorks.TreeSurgeon.UnitTests")]
#endif

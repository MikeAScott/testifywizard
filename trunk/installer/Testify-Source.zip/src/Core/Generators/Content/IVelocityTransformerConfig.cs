namespace ThoughtWorks.TreeSurgeon.Core.Generators.Content
{
	public interface IVelocityTransformerConfig
	{
		string TemplateDirectory { get; }
	}
}
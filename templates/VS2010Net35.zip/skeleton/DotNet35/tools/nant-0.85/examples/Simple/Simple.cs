public class Simple {
    static void Main() {
        System.Console.WriteLine("Hello, World!");
    }
}

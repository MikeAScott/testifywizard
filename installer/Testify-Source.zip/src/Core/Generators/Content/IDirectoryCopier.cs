namespace ThoughtWorks.TreeSurgeon.Core.Generators.Content
{
	public interface IDirectoryCopier
	{
		void CopyDirectory(string sourceDirectory, string targetDirectory);
	}
}
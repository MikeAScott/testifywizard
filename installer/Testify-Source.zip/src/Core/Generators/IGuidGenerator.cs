namespace ThoughtWorks.TreeSurgeon.Core.Generators
{
	public interface IGuidGenerator
	{
		string GenerateGuid();
	}
}